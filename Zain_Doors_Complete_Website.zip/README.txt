ZAIN DOORS WEBSITE

Files:
- index.html = complete responsive website
- images/ = your six supplied door photos

Contact used:
Phone/WhatsApp: +92 304 2011948
Name: Mahmood Anjum Nomi
Address: Nawab Town, Raiwind Road, near Jan Muhammad Road, Lahore

To test:
Open index.html in Chrome.

To publish:
Upload index.html and the images folder to a web host. A custom domain can be connected later.
